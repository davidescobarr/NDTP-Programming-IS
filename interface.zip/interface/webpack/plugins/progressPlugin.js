const webpack = require('webpack');

module.exports = new webpack.ProgressPlugin();

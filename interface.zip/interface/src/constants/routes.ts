export const MAIN = '/' as const;
export const ESTABLISHMENTS = '/Establishments' as const;
export const PROFESSIONS = '/Main' as const;
export const PROFILE = '/Profile' as const;
export const TESTS = '/Tests' as const;
export const LOGIN = '/Login' as const;
export const REGISTRATION = '/Registration' as const;
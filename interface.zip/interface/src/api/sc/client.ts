import { SC_URL } from '@constants';
import { ScClient } from 'ts-sc-client';

export const client = new ScClient(SC_URL);

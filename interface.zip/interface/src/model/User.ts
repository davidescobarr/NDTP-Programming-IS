import { Role } from '@model';

export interface IUser {
    id: string;
    name: string;
    role: Role;
}
